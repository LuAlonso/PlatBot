extends CharacterBody3D


const SPEED = 3.0
# Change the way he is moving x,y,z 0 or 1 or -1
# Export direction so you can make every unique enemy move differently
@export var direction := Vector3(1,0,0)
var turning := false

func _physics_process(delta: float) -> void:
	velocity.x = SPEED * direction.x
	velocity.z = SPEED * direction.z
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta


	move_and_slide()

	# Turn around when enemy hits walls
	if is_on_wall() and not turning:
		turn_around()
		
func turn_around():
	turning = true
	var dir = direction
	direction = Vector3.ZERO
	var turn_tween = create_tween()
	turn_tween.tween_property(self, "rotation_degrees", Vector3(0,180,0), 0.6).as_relative()
	await get_tree().create_timer(0.6).timeout
	
	direction.x = dir.x * -1
	direction.z = dir.z * -1
	turning = false


func _on_sides_checker_body_entered(_body: Node3D) -> void:
	get_tree().change_scene_to_file.call_deferred("res://level_1.tscn")
